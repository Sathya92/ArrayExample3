
public class OrdArray {
	private long[] a;
	private int nElems;

	

	// -----------------------------
	public OrdArray(int max) {
		a = new long[max];
		nElems = 0;
	}

	// ------------------------------
	public int size() {
		return nElems;
	}

	// -------------------------------
	public int find(long searchKey) {
		int lowerBound = 0;
		int upperBound = nElems - 1;
		int curIn;

		while (true) {
			curIn = (lowerBound + upperBound) / 2;
			if (a[curIn] == searchKey)
				return curIn;
			else if (lowerBound > upperBound)
				return nElems;
			else {
				if (a[curIn] < searchKey)
					lowerBound = curIn + 1;
				else
					upperBound = curIn - 1;
			}
		}
	}
	
	//-------------------------------------
	public long[] insert(long value){
		int j=0;
		for(j=0;j<nElems;j++)
		if(a[j]> value)
		break;
			for(int k=nElems;k>j;k--)
			a[k]=a[k-1];
		
		a[j]=value;
		nElems++;
		return a;
		
	}
	
	
	//-----------------------------------------
	public boolean delete(long value){
		int k = find(value);
		if(k==nElems)
			return false;
		else
		{
			for(int j =k;j<nElems;j++)
				a[j]=a[j+1];
			nElems--;
			return true;
		}
	}
	
	//----------------------------------------------
	public void display(){
		for(int i=0;i<nElems;i++)
			System.out.print(a[i]+" ");
		System.out.println(" ");
		
	}
	
	//-----------------MERGE() METHOD------------------------------
	public void merge(long[] arr1, long[] arr2,int length1, int length2){
		long[] temp1;
		long[] temp2;
		int length = length1+length2;
		temp1 = new long[length];
		temp2 = new long[length];
		
		OrdArray temp;
		temp = new OrdArray(length);
		
		for(int i=0;i<length;i++)
			temp1[i]=arr1[i];
		for(int j=0;j<length;j++)
			temp2[j]=arr2[j];
		for(int k =0;k<length;k++)
			temp.insert();
		System.out.print(temp2[k]+" ");
		System.out.println(" ");
	}
	

}
